Name: Ryan Russell
UIN: 227006614
Section: CSCE 121-530
Username: rhrussell
Email: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions and code
to the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help on this academic work.
Ryan Russell	10/4/19

Problem 2: I learned from writing this program how to add to the recursive part
of the function therefore adding to your answer each time. The results of my testing
where that if the decimal number was a multiple of 8, then its octal form would be
a multiple of 10 (ex 56 in base 10 is 70 in base 8) and that also the program can
not work for negative numbers. The only error that I experienced was where exactly
I needed to put the prefix 0 in the program without effecting the answer.