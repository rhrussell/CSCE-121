#include "my.h"

void print_foo()
{
    cout << foo << endl;
}

void print(int i)
{
    cout << i << endl;
}