#include "my.h"
#include <iostream>

int foo;

int main()
{
    foo = 7;
    print_foo();
    int num = 99;
    print(num);
}