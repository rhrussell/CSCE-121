/*  Author: Ryan Russell
    Date: 10/4/19
    Section: CSCE-121-530
    UIN: 227006614
    E-mail: rhrussell@tamu.edu
    Assignment 4 Drill 1: learning how to use header files and global variables
*/

#include <iostream>
using namespace std;

extern int foo;
void print_foo();
void print(int);