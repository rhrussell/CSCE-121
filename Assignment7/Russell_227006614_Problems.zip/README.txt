Name: Ryan Russell
UIN: 227006614
Section: CSCE 121-530
Username: rhrussell
Email: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions
and code to the submitted work.
On my honor as an Aggie, I have neither given nor received any
unauthorized help on this academic work.
Ryan Russell	11/13/19

I had alot of trouble with figuring out the sorting aspect to the Sorted Singly
Linked List. However I figured it out eventually by fixing the pointers.