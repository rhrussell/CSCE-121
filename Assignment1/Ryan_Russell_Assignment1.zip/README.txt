Name: Ryan Russell
UIN: 227006614
Section: CSCE 121-530
Username: rhrussell
Email: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions/code to
the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help on this academic work.
Ryan Russell	9/4/2019

I learned from this assignment how to use Unix commands such as listing items in a folder, 
copying items from one destination to another and renaming the items in a folder.
At first these commands were easy to understand but difficult to implement.
However through this assignment, my knowledge and my confidence on these commands has
increased. Writing my first C++ program was weird because it definitely had 
different syntax than what I am used to;but now that I have a future reference
to use for future programs I have more confidence and passion for learning about
C++.