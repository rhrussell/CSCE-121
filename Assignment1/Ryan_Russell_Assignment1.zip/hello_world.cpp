/*	Author: Ryan Russell
	Date: 8/28/2019
	Section: CSCE-121-530
	UIN: 227006614
	E-mail: rhrussell@tamu.edu
	Assignment 1: Learning how to print statements and how to build a program
*/

#include <iostream>

int main()
{
    std::cout << "Hello World!\n"; 
}

