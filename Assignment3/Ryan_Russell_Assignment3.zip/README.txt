Name: Ryan Russell
UIN: 227006614
Section: CSCE 121-530
Username: rhrussell
E-mail: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions/code to the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Ryan Russell	9/22/2019

Problem 4
I have learned from this assignment how to use a switch statement using the results
from a function. The results of my testing show that the program works for
all quadratic functions. The only errors I experienced was working with the dealing with
the reference variables x1 and x2.

Problem 5
Out of the 10 people I asked, 60% of the people confirmed that they were in that category.
I learned how to convert integers to strings and add those strings together. The program
originally did not work for the number 10.
