Name: Ryan Russell
UIN: 227006614
Section: CSCE 121-530
Username: rhrussell
Email: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions
and code to the submitted work.
On my honor as an Aggie, I have neither given nor received any
unauthorized help on this academic work.
Ryan Russell	11/4/2019

I tested my programs by implementng short parts to the problem and printing the
current data to see where I was at currently in solving the problem.