Name: Ryan Russell
UIN: 227006614
Section: CSCE 121-530
Username: rhrussell
Email: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions/
the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help on this academic work.
Ryan Russell	9/15/2019

Program 2
. Forgetting to put endl at the end of statements.
. Used double quotations instead of single quotations for char varaible
. Used << for cin input instead of  >>
. Used = when comparing char varaibles insteado of ==

These are the mistakes that I made while trying to write the solution to Program 2.
I learned from these mistakes by trying to run the code and fixing the errors that
popped up along the way of writing/compiling the program.

Program 3
This program further expanded my knowledge of inputting varaibles with cin which helped
me learn from my previous mistakes in Program 2.

Program 4
Case 1: Number = 5: Questions Asked = 6
Case 2: Number = 2: Questions Asked = 5
Case 3: Number = 47: Questions Asked = 6
Case 4: Number = 33: Questions Asked = 6
Case 5: Number = 11: Questions Asked = 6

I learned how to write a seperate function and how to call on it in the main 
function multiple times. The results of my testing showed that my program will
most likely guess the number correctly in 6 or less questions.

Program 5
I have learned how to deal with variables that hold a single element which then
are added to another variable that holds the sum of multiple variables and also
how to manipulate the sum variables. The errors I had with this program is that my
total scores would come out incorrect but I corrected the mistake with fixing the 
mathematics.

Program 6
I learned from this program how to format strings with whitespaces. The only error that I can notice
is that on the left hand side there is one less space between the 9's and 10's and on the right
hand side there is one too many between the 9's and 10's.